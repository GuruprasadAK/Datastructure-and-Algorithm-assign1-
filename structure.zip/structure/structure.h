
typedef struct _employee_ EMP;
struct _employee_ {
    char name[20];
    int empID;
    int phone;
    char desig[20];
    int salary;
};
int append();
int same_desig_tot_sal();

