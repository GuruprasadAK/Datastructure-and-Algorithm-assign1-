#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "structure.h"

int main()
{
    assert(append("guru",1,855,"senior_manager",12000)==0);
    assert(append("har",2,2366,"Manager",70000)==0);
    assert(append("Amith",3,996455,"assistant_Employee",4000)==0);
    assert(append("Manan",4,933654653,"CEO",900000)==0);
    assert(same_desig_tot_sal()==0);

    return 0;
}
