#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "structure.h"

int append(char name[20],int empid,int phone_no,char desig[20],int sal)
{
FILE *fptr;
fptr = fopen("maa.txt","a");
fprintf(fptr,"\n%s %d %d %s %d",name,empid,phone_no,desig,sal);
fclose(fptr);
return 0;
}

int same_desig_tot_sal()
{
FILE *fptr,*fsenior_manager,*fManager,*fassistant_Employee,*fCEO;
int count1=0,count2=0,count3=0,count4=0,tot_sal=0,count=0;
fptr=fopen("maa.txt","r");
fsenior_manager =fopen("maa1.txt","w");
fManager =fopen("maa2.txt","w");
fassistant_Employee =fopen("maa3.txt","w");
fCEO =fopen("maa4.txt","w");
while(!feof(fptr))
    {
        EMP employ;
        fscanf(fptr,"%s %d %d %s %d",employ.name,&employ.empID,&employ.phone,employ.desig,&employ.salary);
        count++;
        if(strcmpi(employ.desig,"senior_manager")==0)
        {
            count1++;
            fprintf(fsenior_manager,"%s%d%d%s%d\n",employ.name,employ.empID,employ.phone,employ.desig,employ.salary);
        }
        else if(strcmpi(employ.desig,"Manager")==0)
        {
            fprintf(fManager,"%s%d%d%s%d\n",employ.name,employ.empID,employ.phone,employ.desig,employ.salary);
            count2++;
        }
        else if(strcmpi(employ.desig,"assistant_Employee")==0)
        {
            fprintf(fassistant_Employee,"%s%d%d%s%d\n",employ.name,employ.empID,employ.phone,employ.desig,employ.salary);
            count3++;
        }
        else
        {
            fprintf(fCEO,"%s%d%d%s%d\n",employ.name,employ.empID,employ.phone,employ.desig,employ.salary);
            count4++;
        }
        tot_sal=tot_sal+employ.salary;
    }
    printf("senior_manager:%d\tManager:%d\tfassistant_Employee:%d\tCEO:%d\nTotal_salary of all employees:%d\n",count1,count2,count3,count4,tot_sal);
        printf("Total number of employees:%d",count);

    fclose(fptr);
    fclose(fsenior_manager);
    fclose(fManager);
    fclose(fassistant_Employee);
    fclose(fCEO);
    return 0;
}


