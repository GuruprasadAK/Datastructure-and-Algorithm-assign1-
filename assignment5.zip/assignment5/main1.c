#include"main.h"
int longest(FILE *fptr , FILE *fptr1)
{
    char c;
    int count=0,long_len=0;
    while ((c=getc(fptr))!= EOF)
    {
        count++;
        if(c=='\n')
        {
            if(long_len<count)

            {
                long_len=  count;
            }
            fprintf(fptr1,"%d\n",count);
            count=0;
        }

    }
    return long_len;
}
