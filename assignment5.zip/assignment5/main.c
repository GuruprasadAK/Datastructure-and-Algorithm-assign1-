#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<string.h>
int main()
{
	FILE *fptr,*fptr1;
	fptr = fopen("maa1.txt","r");
	fptr1 = fopen("maa2.txt","w");
	assert(longest(fptr ,fptr1)==132);
	fclose(fptr);
	fclose(fptr1);
	return 0;
}
