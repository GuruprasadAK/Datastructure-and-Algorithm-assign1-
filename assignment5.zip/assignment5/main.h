#include<stdio.h>
int longest(FILE *,FILE *);
